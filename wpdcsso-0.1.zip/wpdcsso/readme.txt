=== wpdcsso ===
Contributors: bobrob_atl,ttolle
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 1.0
Tags: DigitalChalk,SSO
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is a plugin for Wordpress that enables Single Sign-On to the DigitalChalk LMS

== Description ==

This is a plugin for Wordpress that enables Single Sign-On to the DigitalChalk LMS

== Installation ==

Install the usual way through the plugins option in Wordpress Admin panel.  No code changes to templates are required.

After installation, go to Settings > Plugins > DigitalChalk SSO and set the parameters for the plugin, based on information from your DigitalChalk instructor account.

== Frequently Asked Questions ==

== Changelog ==

= 1.0 =
* Initial public release.

